package schelling;

/**
 * Schelling's Segregation Model
 *
 * @author Luc Girardin
 * @author Lars-Erik Cederman
 * @author Laszlo Gulyas
 * @version 2.0
 */
import uchicago.src.reflector.RangePropertyDescriptor;
import uchicago.src.sim.engine.Controller;
import uchicago.src.sim.engine.SimInit;
import uchicago.src.sim.engine.SimModel;
import uchicago.src.sim.gui.DisplayConstants;
import uchicago.src.sim.gui.DisplaySurface;
import uchicago.src.sim.gui.Object2DDisplay;
import uchicago.src.sim.analysis.OpenSequenceGraph;
import uchicago.src.sim.analysis.Sequence;
import uchicago.src.sim.analysis.LocalDataRecorder;
import uchicago.src.sim.space.Object2DGrid;

import java.util.Iterator;
import java.util.ArrayList;
import java.util.ListIterator;

public class SegregationBatch extends Segregation {
    // Batch variables
    private int numOfTimeSteps;     // Defines the length of each batch replication run.
    private LocalDataRecorder recorder;  // Repast's mechanism for data recording.
    protected Object2DGrid world2;
    public ArrayList agentList2;

    public SegregationBatch() {
        super();
        Controller.ALPHA_ORDER = false;
        Controller.CONSOLE_ERR = false;
        Controller.CONSOLE_OUT = false;
    }

    public void setup() {
        this.setRngSeed(1);
        super.setup();

        // Set inherited variables
        name = "Schelling's Segregation Model";
        if (schelling) {
            params = new String[]{"WorldSize",
                                  "Balance",
                                  "Empty",
                                  "Limits",
                                  "Deviation",
                                  "Step_By_Step",
                                  "NumOfTimeSteps", "RngSeed"
            };
        } else {
            params = new String[]{"WorldSize",
                                  "Empty",
                                  "Balance",
                                  "Intolerance",
                                  "Step_By_Step",
                                  "NumOfTimeSteps", "RngSeed"
            };
        }

        // Initializing the batch part
        numOfTimeSteps = 400;  // This sets the number of iterations.
    }

    public void buildModel() {
        super.buildModel();

        // Set the number of simulation steps
        setStoppingTime(numOfTimeSteps);

        // Build the Batch-part
        // Create the DataRecorder object and specify the name of the output file.
        // (For details see Repast's appropriate "How to" document.)
        recorder = new LocalDataRecorder("data.txt", this);

        recorder.createNumericDataSource("Regions", this, "regionCounter");
        recorder.createNumericDataSource("Regions2", this, "regionCounter2");
        recorder.createNumericDataSource("Happiness", this, "happiness");
        recorder.setDelimeter(" ");
    }

    public void step() {
        super.step();
    }

    public void atEnd() {
        super.atEnd();

        recorder.record();
        recorder.write();
    }

    public double happiness() {
        return (double) numHappyAgents / (double)agentList.size();
    }

    public void markRegion(Agent a, int numRegions) {
        // We mark the agent as one belonging to the given region
        a.region = numRegions;
        // Then we go through all its neighbors, too.
        Iterator it = world.getVonNeumannNeighbors(a.getX(), a.getY(), false).iterator();
        while (it.hasNext()) {
            Agent neighbor = (Agent) it.next();
            // If the neighbor is unmarked yet, and has the same culture as
            // our initial agent, we mark it (and its similar neighbors) as well.
            if ((neighbor.region == 0) && (a.similarTo(neighbor) == 1.0))
                markRegion(neighbor, numRegions);
        }
    }

    public int regionCounter() {
        // We clear the region field of all the agents first
        Iterator it = agentList.iterator();
        while (it.hasNext()) {
            Agent a = (Agent) it.next();
            a.region = 0;
        }

        // Then we go through all the agents again and
        // assign regional identity to all of them.
        int numRegions = 0;
        it = agentList.iterator();
        while (it.hasNext()) {
            Agent a = (Agent) it.next();
            // If the agent hasn't been reached yet, we start our next
            // region out of it
            if (a.region == 0) {
                numRegions++;
                markRegion(a, numRegions);
            }
        }

        return numRegions;
    }

    public void markRegion2(Agent a, int numRegions) {
        // We mark the agent as one belonging to the given region
        a.region = numRegions;
        // Then we go through all its neighbors, too.
        Iterator it = world2.getVonNeumannNeighbors(a.getX(), a.getY(), false).iterator();
        while (it.hasNext()) {
            Agent neighbor = (Agent) it.next();
            // If the neighbor is unmarked yet, and has the same culture as
            // our initial agent, we mark it (and its similar neighbors) as well.
            if ((neighbor.region == 0) && (a.similarTo(neighbor) == 1.0))
                markRegion2(neighbor, numRegions);
        }
    }

    public void filter() {
        for (int x = 0; x < worldSize; x++) {
            for (int y = 0; y < worldSize; y++) {
                Agent a = (Agent) world.getObjectAt(x, y);
                if (a != null) {
                    world2.putObjectAt(x,y,a);
                    a.region = 0;
                    agentList2.add(a);
                } else {
                    Iterator it = world.getVonNeumannNeighbors(x, y, false).iterator();
                    int c0 = 0;
                    int c1 = 0;
                    while (it.hasNext()) {
                        Agent neighbor = (Agent) it.next();
                        if (neighbor.color == 0)
                            c0++;
                        if (neighbor.color == 1)
                            c1++;
                    }
                    if (c0 > 1 && c1 == 0) {
                        Agent newAgent = new Agent(x, y, 0, this);
                        world2.putObjectAt(x, y, newAgent);
                        agentList2.add(newAgent);
                    }
                    if (c1 > 1 && c0 == 0) {
                        Agent newAgent = new Agent(x, y, 1, this);
                        world2.putObjectAt(x, y, newAgent);
                        agentList2.add(newAgent);
                    }
                }
            }
        }

    }


    public int regionCounter2() {

        // We clear the region field of all the agents first

        world2 = new Object2DGrid(worldSize, worldSize);

        agentList2 = new ArrayList();

        filter();

        // Then we go through all the agents again and
        // assign regional identity to all of them.
        int numRegions = 0;
        ListIterator it = agentList2.listIterator();
        while (it.hasNext()) {
            Agent a = (Agent) it.next();
            // If the agent hasn't been reached yet, we start our next
            // region out of it
            if (a.region == 0) {
                numRegions++;
                markRegion2(a, numRegions);
            }
        }

        return numRegions;
    }

    public void postStep() {
        super.postStep();
    }

    // Probed variables ////////////////////////////////////////

    public int getWorldSize() {
        return worldSize;
    }

    public void setWorldSize(int i) {
        worldSize = i;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public int getEmpty() {
        return empty;
    }

    public void setEmpty(int propEmpty) {
        this.empty = propEmpty;
    }

    public int getIntolerance() {
        return intolerance;
    }

    public void setIntolerance(int intolerance) {
        this.intolerance = intolerance;
    }

    public boolean getStep_By_Step() {
        return !autoStep;
    }

    public void setStep_By_Step(boolean b) {
        autoStep = !b;
    }

    public String getLimits() {
        StringBuffer s = new StringBuffer();
        for (int i = 0; i < 9; i++)
            s.append(limits[i]);
        return s.toString();
    }

    public void setLimits(String s) {
        limits = new int[9];
        int m = s.length();
        if (m > 9)
            m = 9;
        int i;
        for (i = 0; i < m; i++)
            try {
                limits[i] = Integer.parseInt(s.substring(i, i + 1));
            } catch (NumberFormatException e) {
                limits[i] = 0;
            }
        for (; i < m; i++)
            limits[i] = 0;
        // Refreshing the input field
        ((Controller) getController()).display();
    }

    public String getDeviation() {
        StringBuffer s = new StringBuffer();
        for (int i = 0; i < 9; i++)
            s.append(deviation[i]);
        return s.toString();
    }

    public void setDeviation(String s) {
        deviation = new int[9];
        int m = s.length();
        if (m > 9)
            m = 9;
        int i;
        for (i = 0; i < m; i++)
            try {
                deviation[i] = Integer.parseInt(s.substring(i, i + 1));
            } catch (NumberFormatException e) {
                deviation[i] = 0;
            }
        for (; i < m; i++)
            deviation[i] = 0;
    }

    public static void main(String[] args) {
        SimInit init = new SimInit();
        // We MUST create a ModelGUI object instead of an instance of Model
        // as in the parent class, in order to get the GUI functionality.
        SimModel m = new SegregationBatch();
        String filename = "params.txt";
        if(args.length > 0) {
            filename = args[0];
        }
        init.loadModel(m, filename, true);
    }
}