package schelling;

/**
 * Schelling's Segregation Model
 *
 * @author Luc Girardin
 * @author Lars-Erik Cederman
 * @author Laszlo Gulyas
 * @version 2.0
 */
import uchicago.src.sim.engine.SimpleModel;
import uchicago.src.sim.space.Object2DGrid;
import uchicago.src.sim.util.Random;
import uchicago.src.sim.util.SimUtilities;

import java.util.ArrayList;

public class Segregation extends SimpleModel {
    public boolean schelling;
    public int intolerance;

    public int empty = 10;
    public int balance = 0;

    public int worldSize = 30;
    protected Object2DGrid world;
    protected int[] limits = {0, 1, 1, 2, 2, 2, 3, 3, 3};
    protected int[] deviation = {0, 0, 0, 0, 0, 0, 0, 0, 0};
    public int numHappyAgents;

    public Segregation() {
        super();
        autoStep = false;
        shuffle = true;
    }

    public void setup() {
        super.setup();
        schelling = false;
        numHappyAgents = 0;
        intolerance = 33;
    }

    protected void createAgents(int number, int color) {
        for (int i = 0; i < number; i++) {
            int x, y;
            do {
                x = Random.uniform.nextIntFromTo(0, worldSize - 1);
                y = Random.uniform.nextIntFromTo(0, worldSize - 1);
            } while (world.getObjectAt(x, y) != null);

            int[] lims = new int[9];
            for (int j = 0; j < 9; j++) {
                int dev = Random.uniform.nextIntFromTo(-deviation[j],
                        deviation[j]);
                lims[j] = limits[j] + dev;
                if (lims[j] < 0)
                    lims[j] = 0;
                if (lims[j] > j)
                    lims[j] = j;
            }

            Agent newBoy = new Agent(x, y, color, lims, this);
            agentList.add(newBoy);
            world.putObjectAt(x, y, newBoy);
        }
    }

    public void buildModel() {
        super.buildModel();

        world = new Object2DGrid(worldSize, worldSize);

        int size = worldSize * worldSize;
        int agents = size - (int) ((empty / 100.0) * size);
        int numC0 = (int) (agents * ((balance + 50) / 100.0));
        int numC1 = agents - numC0;

        createAgents(numC0, 0);
        createAgents(numC1, 1);
    }

    public void step() {
        super.step();

        ArrayList list = new ArrayList();
        int size = agentList.size();
        for (int i = 0; i < size; i++) {
            Agent agent = (Agent) agentList.get(i);
            if (agent.wantToMoveFrom(agent.x, agent.y))
                list.add(agent);
        }
        if (!list.isEmpty()) {
            SimUtilities.shuffle(list);
            Agent agent = (Agent) list.get(0);
            agent.step();
        }
        measureHappiness();
    }

    public void measureHappiness() {
        numHappyAgents = 0;
        for (int i = 0; i < agentList.size(); i++) {
            Agent agent = (Agent) agentList.get(i);
            if (agent.isHappy()) {
                numHappyAgents++;
            }
        }
    }
}