package schelling;

/**
 * Schelling's Segregation Model
 *
 * @author Luc Girardin
 * @author Lars-Erik Cederman
 * @author Laszlo Gulyas
 * @version 2.0
 */
import uchicago.src.sim.gui.Drawable;
import uchicago.src.sim.gui.SimGraphics;
import uchicago.src.sim.util.SimUtilities;

import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Vector;

public class Agent implements Drawable {
    protected int x, y, color;
    protected int[] limits;
    protected Segregation model;
    protected int id;           // For identification when probing
    int region;                        // Regional index, used in region counter

    public Agent(int x, int y, int color, int[] lims, Segregation model) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.model = model;

        id = 1000 * x + y;

        int m = lims.length;
        if (m > 9)
            m = 9;
        limits = new int[9];
        int i;
        for (i = 0; i < m; i++)
            limits[i] = lims[i];
        for (; i < 9; i++)
            limits[i] = 8;
        region = 0;
    }

    public Agent(int x, int y, int color, Segregation model) {
        this.x = x;
        this.y = y;
        this.color = color;
        this.model = model;

        id = 1000 * x + y;
        region = 0;
    }

    int numNeigh, numNotAlike;

    protected void makeNeighborStatistics(int px, int py) {
        Vector neighbors = model.world.getMooreNeighbors(px, py, false);
        numNeigh = neighbors.size();

        // Counting Alike Neighbors
        numNotAlike = 0;
        Iterator i = neighbors.iterator();
        while (i.hasNext()) {
            Agent a = (Agent) i.next();
            if (a.color != color)
                numNotAlike++;
        }
    }

    protected boolean wantToMoveFrom(int px, int py) {
        makeNeighborStatistics(px, py);
        double numAlike = numNeigh - numNotAlike;
        if (model.schelling)
            return (numAlike < limits[numNeigh]);
        else
            return (numAlike < (model.intolerance / 100.0) * (double) numNeigh);

    }

    public boolean isHappy() {
        return !wantToMoveFrom(x,y);
    }

    class Position {
        int x, y;

        public Position(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    protected double distanceFromXY(int i, int j) {
        return Math.sqrt((x - i) * (x - i) + (y - j) * (y - j));
    }

    protected Position determineMove() {
        ArrayList list = new ArrayList();
        double minDist = model.worldSize * model.worldSize;

        for (int i = 0; i < model.worldSize; i++)
            for (int j = 0; j < model.worldSize; j++) {
                if (model.world.getObjectAt(i, j) == null) {
                    // Getting ourselves off the table before
                    // making statistics
                    model.world.putObjectAt(x, y, null);
                    if (!wantToMoveFrom(i, j)) {
                        double d = distanceFromXY(i, j);
                        if (d <= minDist) {
                            if (d < minDist) {
                                list.clear();
                                minDist = d;
                            }
                            list.add(new Position(i, j));
                        }
                    }
                    // Putting ourselves back at the table
                    model.world.putObjectAt(x, y, this);
                }
            }

        if (list.isEmpty())
            return null;
        else {
            SimUtilities.shuffle(list);
            return (Position) list.get(0);
        }
    }

    protected void moveTo(int xx, int yy) {
        model.world.putObjectAt(x, y, null);
        model.world.putObjectAt(xx, yy, this);
        x = xx;
        y = yy;
    }

    /**
     * Method for Stepable
     */
    public void step() {
        if (wantToMoveFrom(x, y)) {
            Position p = determineMove();
            if (p != null)
                moveTo(p.x, p.y);
        }
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void draw(SimGraphics g) {
        Color drawingColor;

        if (color == 0)
            drawingColor = Color.red;
        else
            drawingColor = Color.blue;
        g.drawRoundRect(drawingColor);

        g.drawHollowRect(Color.darkGray);
    }

    public int getID() {
        return id;
    }

    public String getLimits() {
        StringBuffer s = new StringBuffer();
        for (int i = 0; i < 9; i++)
            s.append(limits[i]);
        return s.toString();
    }

    public void setLimits(String s) {
        limits = new int[9];
        int m = s.length();
        if (m > 9)
            m = 9;
        int i;
        for (i = 0; i < m; i++)
            try {
                limits[i] = Integer.parseInt(s.substring(i, i + 1));
            } catch (NumberFormatException e) {
                limits[i] = 0;
            }
        for (; i < m; i++)
            limits[i] = 0;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int c) {
        if (c < 1)
            color = 0;
        else
            color = 1;

        // Refreshing the input field
        ((SegregationGUI) model).dsurf.display();
    }

    /**
     * Returns the cultural similarity to another actor a
     * @param a
     * @return No traits similar = 0.0;  all traits the same = 1.0
     */
    public double similarTo(Agent a) {
        if(color != a.color) {
            return 0.0;
        } else {
            return 1.0;
        }
    }

}