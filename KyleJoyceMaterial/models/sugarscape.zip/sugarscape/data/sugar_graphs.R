#set working directory

sugar.data.400 <- read.csv("sugar_data_collapsed_400.csv",sep=",",header=T)
sugar.data.800 <- read.csv("sugar_data_collapsed_800.csv",sep=",",header=T)

par(mfrow=c(2,1))

#Results for 400 agents
plot(sugar.data.400$tick,sugar.data.400$mean_vision,type="l",lwd=2,col="red",ylim=c(0,4),xlab="Tick",ylab="Mean",main="400 Agents")
lines(sugar.data.400$tick,sugar.data.400$mean_metabolism,lwd=2,col="blue")

#Results for 800 agents
plot(sugar.data.800$tick,sugar.data.800$mean_vision,type="l",lwd=2,col="red",ylim=c(0,4),xlab="Tick",ylab="Mean",main="800 Agents")
lines(sugar.data.800$tick,sugar.data.800$mean_metabolism,lwd=2,col="blue")

#You should also add a legend
#leg.txt <- c("Vision","Metabolism")
#legend(.,.,leg.txt,lty=c(1,1),col=c("red","blue"),lwd=c(2,2))
